//
//  MASExampleDistributeView.h
//  Masonry iOS Examples
//
//  Created by bibibi on 15/8/6.
//  Copyright (c) 2015年 Jonas Budelmann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASExampleDistributeView : UIView

@end
