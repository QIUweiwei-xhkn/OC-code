//
//  MASExampleSafeAreaLayoutGuideViewController.h
//  Masonry iOS Examples
//
//  Created by MingLQ on 2017-09-27.
//  Copyright © 2017 MingLQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASExampleSafeAreaLayoutGuideViewController : UIViewController

@end
